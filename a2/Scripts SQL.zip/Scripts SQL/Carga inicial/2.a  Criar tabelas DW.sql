--Criando tabelas DW

CREATE TABLE Calendario
( CalendarioChave INT IDENTITY(1, 1) PRIMARY KEY,
DataCompleta DATE,
DiaDaSemana CHAR(15),
DiaDoMes INT,
Trimestre INT,
Mes CHAR(15),
Ano INT,
);


CREATE TABLE Cliente
( ClienteChave INT IDENTITY(1, 1) PRIMARY KEY,
ClienteNome VARCHAR(150),
ClienteCidade VARCHAR(150),
ClienteLogradouro CHAR(150),
ClienteEstado VARCHAR(150),
ClienteCEP CHAR(9),
ClienteBairro VARCHAR(150)
);

CREATE TABLE Funcionario
(FuncionarioChave INT IDENTITY(1, 1) PRIMARY KEY,
FuncionarioNome CHAR(150),
Cargo CHAR(100),
Salario DECIMAL(9,2)
);



CREATE TABLE Formacao
(FormacaoChave INT IDENTITY(1, 1) PRIMARY KEY,
FormacaoNome VARCHAR(150),
ESpecialidade VARCHAR(100),
ValorAula DECIMAL(9,2)
);

CREATE TABLE Despesa
(FuncionarioChave INT,
CalendarioChave INT,
TransacaoPagamentoID INT,
Despesa DECIMAL(9,2),
HoraPagamento TIME,
PRIMARY KEY (TransacaoPagamentoID),
FOREIGN KEY (CalendarioChave) REFERENCES Calendario,
FOREIGN KEY (FuncionarioChave) REFERENCES Funcionario)



CREATE TABLE Receita
(ClienteChave INT,
CalendarioChave INT,
FormacaoChave INT,
TransacaoCompraID INT,
Hora TIME,
ValorCobrado DECIMAL(9,2),
PacoteID INT,
PacoteNome VARCHAR(100),
PRIMARY KEY (TransacaoCompraID, FormacaoChave),
FOREIGN KEY (CalendarioChave) REFERENCES Calendario,
FOREIGN KEY (FormacaoChave) REFERENCES Formacao,
FOREIGN KEY (ClienteChave) REFERENCES Cliente);






