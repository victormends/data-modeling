Populando DW



insert into A2G4EAL.dbo.calendario
select distinct	
	[date], 
	DATENAME(weekday, [date]),
	day([date]), 
	DATENAME(quarter, [date]),
	DATENAME(month, [date]),
	year([date])	
 from (select date from purchase union all select date from payment) as a


insert into A2G4EAL.dbo.Cliente
select 
	c.[name],
	a.[city],
	a.[street],
	a.[state],
	a.[zipcode],
	a.[district]
from customer c left join adress a on c.adress_id = a.id




insert into A2G4EAL.dbo.Funcionario
select distinct
	s.[name],
	j.[title],
	p.[salary]
from staff s, job_title j, payment p 
where s.job_title_id = j.id
and s.id = p.staff_id




insert into A2G4EAL.dbo.Formacao
select 
	distinct
	ct.title,
	ct.speciality,
	ct.cost
from class c left join class_type ct on c.class_type_id = ct.id




insert into A2G4EAL.dbo.Receita
select distinct
	dw_cl.ClienteChave,
	dw_c.CalendarioChave,
	dw_f.FormacaoChave,
	pu.id,
	pu.time, 
	count(ct.id) * ct.cost,
	pu.package_id
	,p.title
from purchase pu, customer c, package p, class cl, class_type ct,   
[A2G4EAL].dbo.Calendario dw_c, [A2G4EAL].dbo.Formacao dw_f, [A2G4EAL].dbo.Cliente dw_cl
where  pu.customer_id = c.id 
and pu.package_id = p.id
and pu.date = dw_c.DataCompleta
and cl.package_id = p.id
and cl.class_type_id = ct.id
and dw_f.FormacaoNome = ct.title 
and dw_f.Especialidade = ct.speciality
and c.name = dw_cl.ClienteNome
group by 
	dw_cl.ClienteChave,
	dw_c.CalendarioChave,
	dw_f.FormacaoChave,
	pu.id,
	pu.time, 
	pu.package_id,
	p.title,
	ct.cost




insert into A2G4EAL.dbo.Despesa
SELECT 
	dw_f.FuncionarioChave, 
	dw_c.CalendarioChave,
	p.id, 
	p.salary,
	p.time
FROM payment p, staff s,  [A2G4EAL].dbo.Funcionario dw_f, [A2G4EAL].dbo.Calendario dw_c
where p.staff_id = s.id
and s.name = dw_f.FuncionarioNome
and p.date = dw_c.DataCompleta

