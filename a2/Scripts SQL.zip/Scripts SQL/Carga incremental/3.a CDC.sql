-----------------------------------------------------------------------
--JOB TITLE 

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'job_title',
@capture_instance = N'job_title', 
@role_name = NULL,
@supports_net_changes = 1
go

--INSERIR NOVO CARGO NA BASE
insert into job_title values (9, 'Instrutor', 'Seguran�a')

declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('job_title');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, title, specialty
into A2G4EAL.dbo.staging_dbo_job_title FROM
[cdc].[fn_cdc_get_net_changes_job_title](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'job_title',
@capture_instance = N'job_title'
go

-----------------------------------------------------------------------
--STAFF

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'staff',
@capture_instance = N'staff', 
@role_name = NULL,
@supports_net_changes = 1
go

--INSERIR NOVO FUNCIONARIO
insert into staff values (11, 'Joseph John', '12332145665', 9, 'johnjohn@nnn.com','44485463033', '1987-06-04', 20)


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('staff');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, name, job_title_id
into A2G4EAL.dbo.staging_dbo_staff FROM
[cdc].[fn_cdc_get_net_changes_staff](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'staff',
@capture_instance = N'staff'
go

-----------------------------------------------------------------------
--PACOTE

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'package',
@capture_instance = N'package', 
@role_name = NULL,
@supports_net_changes = 1
go


insert into package values(6, 'Curso Complementar Seguran�a', 'busca melhorar a segun�a de todos', 300, '12-05-2022', 3);

declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('package');
SET @E = sys.fn_cdc_get_max_lsn();
select @S
select @E
SELECT id, title, cost
into A2G4EAL.dbo.staging_dbo_package FROM
[cdc].[fn_cdc_get_net_changes_package](@S,@E,'all');


EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'package',
@capture_instance = N'package'
go


-----------------------------------------------------------------------
--CLASS TYPE

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'class_type',
@capture_instance = N'class_type', 
@role_name = NULL,
@supports_net_changes = 1
go


insert into class_type values (12, 'Aula Pratica', 100, 'Seguran�a')
insert into class_type values (13, 'Aula Teorica', 100, 'Seguran�a')



declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('class_type');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, title, cost, speciality
into A2G4EAL.dbo.staging_dbo_class_type FROM
[cdc].[fn_cdc_get_net_changes_class_type](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'class_type',
@capture_instance = N'class_type'
go


-----------------------------------------------------------------------
--CLASS 

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'class',
@capture_instance = N'class', 
@role_name = NULL,
@supports_net_changes = 1
go

insert into class values (19, 'Aula Pratica 1', 11, 6, '12-10-2022', '14:00', 12, '00:50')
insert into class values (20, 'Aula Pratica 2', 11, 6, '12-12-2022', '14:00', 12, '00:50')
insert into class values (21, 'Aula Teorica 1', 11, 6, '12-14-2022', '14:00', 13, '00:50')


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('class');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, title, package_id, date, time, class_type_id
into A2G4EAL.dbo.staging_dbo_class FROM
[cdc].[fn_cdc_get_net_changes_class](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'class',
@capture_instance = N'class'
go



-----------------------------------------------------------------------
--CUSTOMER

EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'customer',
@capture_instance = N'customer', 
@role_name = NULL,
@supports_net_changes = 1
go

--INSERIR NOVO CLIENTE
insert into customer values (101, 'Ana Bia Fontes', '14566792301', '03-03-1998', '02198876273', 'aninha@gmail.com', 21);


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('customer');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, name, adress_id
into A2G4EAL.dbo.staging_dbo_customer FROM
[cdc].[fn_cdc_get_net_changes_customer](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'customer',
@capture_instance = N'customer'
go



-----------------------------------------------------------------------
--ADRESS


EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'adress',
@capture_instance = N'adress', 
@role_name = NULL,
@supports_net_changes = 1
go

insert into adress values (21, '123 Flowers', 'Barra Mansa', 'Rio de Janeiro', '112345111', 'Montes' );


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('adress');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, street, city, state, zipcode, district
into A2G4EAL.dbo.staging_dbo_adress FROM
[cdc].[fn_cdc_get_net_changes_adress](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'adress',
@capture_instance = N'adress'
go


-----------------------------------------------------------------------
--PURCHASE


EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'purchase',
@capture_instance = N'purchase', 
@role_name = NULL,
@supports_net_changes = 1
go

insert into purchase values (101, 101, 6, '2022-11-11', '12:45')


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('purchase');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, customer_id, package_id, date, time
into A2G4EAL.dbo.staging_dbo_purchase FROM
[cdc].[fn_cdc_get_net_changes_purchase](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'purchase',
@capture_instance = N'purchase'
go



-----------------------------------------------------------------------
--PAYMENT


EXEC sys.sp_cdc_enable_table
@source_schema = N'dbo',
@source_name = N'payment',
@capture_instance = N'payment', 
@role_name = NULL,
@supports_net_changes = 1
go


insert into payment values (44, 300, '12-01-2022', '10:09', 3, 3)
insert into payment values (45, 600, '12-01-2022', '10:30', 2, 2)
insert into payment values (46, 1000, '12-02-2022', '17:17', 9, 11)


declare @S binary(10);
declare @E binary(10);
SET @S = sys.fn_cdc_get_min_lsn('payment');
SET @E = sys.fn_cdc_get_max_lsn();
SELECT id, salary, date, time, job_title_id, staff_id
into A2G4EAL.dbo.staging_dbo_payment FROM
[cdc].[fn_cdc_get_net_changes_payment](@S,@E,'all');

EXEC sys.sp_cdc_disable_table
@source_schema = N'dbo',
@source_name = N'payment',
@capture_instance = N'payment'
go
