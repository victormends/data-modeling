--Updating Calendario
insert into A2G4EAL.dbo.calendario
select distinct
	[date], 
	DATENAME(weekday, [date]),
	day([date]), 
	DATENAME(quarter, [date]),
	DATENAME(month, [date]),
	year([date])	
 from  (select date from A2G4EAL.dbo.staging_dbo_purchase union all select date from A2G4EAL.dbo.staging_dbo_payment
 where date not in (select distinct datacompleta from A2G4EAL.dbo.calendario )) as a


 --Updating Cliente
insert into A2G4EAL.dbo.Cliente
select 
	c.[name],
	a.[city],
	a.[street],
	a.[state],
	a.[zipcode],
	a.[district]
from a2g4eal.dbo.staging_dbo_customer c left join a2g4eal.dbo.staging_dbo_adress a on c.adress_id = a.id




 --Updating Customer
 insert into A2G4EAL.dbo.Funcionario
select distinct
	s.[name],
	j.[title],
	p.[salary]
from a2g4eal.dbo.staging_dbo_staff s, a2g4eal.dbo.staging_dbo_job_title j, a2g4eal.dbo.staging_dbo_payment p 
where s.job_title_id = j.id
and s.id = p.staff_id
union all
--caso em que o salario muda e o funcionario e seu respectivo cargo ja estavam na base
--neste caso precisamos adicionar uma nova chave e informa��o para o mesmo funcionario
select * from (
select distinct
	s.[name],
	j.[title],
	p.[salary]
from staff s, job_title j, a2g4eal.dbo.staging_dbo_payment p 
where s.job_title_id = j.id
and s.id = p.staff_id) as c
where CONCAT(c.name, c.salary)  not in 
(select CONCAT(name, salary) from A2G4EAL.dbo.Funcionario )



 
--Updating Formacao
insert into A2G4EAL.dbo.Formacao
select 
	distinct
	ct.title,
	ct.speciality,
	ct.cost
--so vamos adicionar as aulas no caso em que houve turmas abertas, ou seja, que houve receita (purchase)
from a2g4eal.dbo.staging_dbo_class c left join a2g4eal.dbo.staging_dbo_class_type ct
on c.class_type_id = ct.id





--Updating Receita
insert into A2G4EAL.dbo.Receita
select distinct
	dw_cl.ClienteChave,
	dw_c.CalendarioChave,
	dw_f.FormacaoChave,
	pu.id,
	pu.time, 
	count(ct.id) * ct.cost,
	pu.package_id
	,p.title
--vamos olhar apenas no nivel dos novos dados de compra
--pq a compra pode se referir a clientes/aulas/pacotes/etc que j� existiam no dw
from a2g4eal.dbo.staging_dbo_purchase pu, customer c, package p, class cl, class_type ct,   
[A2G4EAL].dbo.Calendario dw_c, [A2G4EAL].dbo.Formacao dw_f, [A2G4EAL].dbo.Cliente dw_cl
where  pu.customer_id = c.id 
and pu.package_id = p.id
and pu.date = dw_c.DataCompleta
and cl.package_id = p.id
and cl.class_type_id = ct.id
and dw_f.FormacaoNome = ct.title 
and dw_f.Especialidade = ct.speciality
and c.name = dw_cl.ClienteNome
group by 
	dw_cl.ClienteChave,
	dw_c.CalendarioChave,
	dw_f.FormacaoChave,
	pu.id,
	pu.time, 
	pu.package_id,
	p.title,
	ct.cost



--Updating Despesa
insert into A2G4EAL.dbo.Despesa
SELECT 
	dw_f.FuncionarioChave, 
	dw_c.CalendarioChave,
	p.id, 
	p.salary,
	p.time
FROM a2g4eal.dbo.staging_dbo_payment p, staff s,  [A2G4EAL].dbo.Funcionario dw_f, [A2G4EAL].dbo.Calendario dw_c
where p.staff_id = s.id
and s.name = dw_f.FuncionarioNome
and p.date = dw_c.DataCompleta


--apagar tabelas temporarias 
--drop table a2g4eal.dbo.staging_dbo_payment 
--drop table a2g4eal.dbo.staging_dbo_class
--drop table a2g4eal.dbo.staging_dbo_class_type
--drop table a2g4eal.dbo.staging_dbo_customer
--drop table a2g4eal.dbo.staging_dbo_adress
--drop table a2g4eal.dbo.staging_dbo_package
--drop table a2g4eal.dbo.staging_dbo_purchase
--drop table a2g4eal.dbo.staging_dbo_staff
--drop table a2g4eal.dbo.staging_dbo_job_title